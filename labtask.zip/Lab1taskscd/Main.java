
public class Main {

	public static void main(String[] args) {
		        int num1 = 5;
		        int num2 = 10;
		        int sum = num1 + num2;
		        System.out.println("The sum is: " + sum);
		    }
		
	}


